import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../assets/icons/mr brands logo.png';

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('userData');
    setIsLoggedIn(!!userData);
  }, []);

  useEffect(() => {
    // Fetch product data from public/assets
    const fetchProducts = async () => {
      try {
        const response = await fetch('/assets/product.json');
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Failed to fetch products:', error);
      }
    };

    fetchProducts();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('userData');
    setIsLoggedIn(false);
    navigate('/login');
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    if (value.length > 0) {
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filtered.slice(0, 5));
    } else {
      setSuggestions([]);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
    setSuggestions([]);
  };

  return (
    <header style={{ padding: '10px 20px', backgroundColor: '#6200ea', color: 'white', position: 'relative' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <img
          src={logo}
          alt="MyShop Logo"
          style={{ height: '40px', cursor: 'pointer' }}
          onClick={() => navigate('/')}
        />

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} style={{ flex: 1, margin: '0 20px', position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', backgroundColor: 'white', borderRadius: '5px', width: '100%' }}>
            <input
              type="text"
              value={searchTerm}
              onChange={handleSearchChange}
              placeholder="Search products..."
              style={{
                padding: '8px',
                border: 'none',
                borderRadius: '5px',
                width: '100%',
                minWidth: '150px',
                outline: 'none',
                fontSize: '14px',
              }}
            />
            <img
              src="https://cdn-icons-png.flaticon.com/512/622/622669.png"
              alt="Search"
              style={{ height: '20px', marginRight: '10px' }}
            />
          </div>

          {suggestions.length > 0 && (
            <ul
              style={{
                position: 'absolute',
                top: '40px',
                left: 0,
                width: '100%',
                background: 'white',
                color: 'black',
                borderRadius: '5px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
                zIndex: 1000,
                listStyle: 'none',
                padding: 0,
                margin: 0,
              }}
            >
              {suggestions.map((product) => (
                <li
                  key={product.id}
                  onClick={() => {
                    navigate(`/search?q=${encodeURIComponent(product.name)}`);
                    setSearchTerm(product.name);
                    setSuggestions([]);
                  }}
                  style={{
                    padding: '10px',
                    cursor: 'pointer',
                    borderBottom: '1px solid #eee',
                  }}
                >
                  {product.name}
                </li>
              ))}
            </ul>
          )}
        </form>

        <nav style={{ display: 'flex', gap: '15px' }}>
          <Link to="/" style={linkStyle}>Home</Link>
          <Link to="/cart" style={linkStyle}>Cart</Link>
          {isLoggedIn ? (
            <>
              <Link to="/profile" style={linkStyle}>Profile</Link>
              <button onClick={handleLogout} style={logoutButtonStyle}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" style={linkStyle}>Login</Link>
              <Link to="/register" style={linkStyle}>Register</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

const linkStyle = {
  color: 'white',
  textDecoration: 'none',
  fontWeight: '500',
};

const logoutButtonStyle = {
  background: 'none',
  border: 'none',
  color: 'white',
  fontWeight: '500',
  cursor: 'pointer',
  padding: 0,
};

export default Header;

