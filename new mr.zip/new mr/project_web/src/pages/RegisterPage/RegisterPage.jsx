import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const RegisterPage = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    contact: '',
    address: '',
    birthdate: '',
    orderedProducts: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Save the full user data (including password) in localStorage
    localStorage.setItem('userData', JSON.stringify(formData));
    navigate('/profile');
  };

  const handleLoginRedirect = () => {
    navigate('/login');
  };

  return (
    <div className="register-form">
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="firstName" placeholder="First Name" onChange={handleChange} required />
        <input type="text" name="lastName" placeholder="Last Name" onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
        <input type="text" name="contact" placeholder="Contact Number" onChange={handleChange} required />
        <input type="text" name="address" placeholder="Address" onChange={handleChange} required />
        <input type="date" name="birthdate" onChange={handleChange} required />
        <button type="submit">Register</button>
      </form>

      <p style={{ marginTop: '1rem' }}>
        Already registered?{' '}
        <button style={{ background: 'none', color: 'blue', border: 'none', cursor: 'pointer' }} onClick={handleLoginRedirect}>
          Login
        </button>
      </p>
    </div>
  );
};

export default RegisterPage;


