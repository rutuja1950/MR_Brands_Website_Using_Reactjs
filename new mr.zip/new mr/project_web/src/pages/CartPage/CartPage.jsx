// src/pages/CartPage/CartPage.jsx
import React, { useContext } from 'react';
import { CartContext } from '../../context/CartContext';

const CartPage = () => {
  const { cartItems, removeFromCart } = useContext(CartContext);

  const total = cartItems.reduce((acc, item) => acc + Number(item.price), 0);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Your Cart</h1>

      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px' }}>
            {cartItems.map((item) => (
              <div
                key={item.id}
                style={{ border: '1px solid #ccc', padding: '10px', borderRadius: '10px' }}
              >
                <img
                  src={item.images?.split('~')[0].trim()}
                  alt={item.name}
                  style={{ width: '100%', height: '200px', objectFit: 'cover' }}
                />
                <h3>{item.name}</h3>
                <p>₹{item.price}</p>
                <button
                  onClick={() => removeFromCart(item.id)}
                  style={{
                    backgroundColor: '#e63946',
                    color: 'white',
                    padding: '5px 10px',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    marginTop: '10px'
                  }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
          <h2 style={{ marginTop: '20px' }}>Total: ₹{total}</h2>
        </>
      )}
    </div>
  );
};

export default CartPage;

