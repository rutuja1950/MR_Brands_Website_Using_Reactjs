import React, { useContext } from 'react';
import { useProduct } from '../../context/ProductContext';
import { CartContext } from '../../context/CartContext';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const { products } = useProduct();
  const { addToCart } = useContext(CartContext);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Welcome to MyShop</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {products.slice(0, 16).map((product) => (
          <div
            key={product.id}
            style={{
              width: '23%',
              margin: '1%',
              border: '1px solid #ccc',
              padding: '10px',
              boxSizing: 'border-box'
            }}
          >
            <img
              src={product.images}
              alt={product.name}
              style={{ width: '100%', height: '200px', objectFit: 'cover' }}
            />
            <h3>{product.name}</h3>
            <p>₹{product.price}</p>
            <Link to={`/product/${product.id}`}>View</Link>
            <br />
            <button
              onClick={() => addToCart(product)}
              style={{
                marginTop: '10px',
                backgroundColor: '#4CAF50',
                color: 'white',
                border: 'none',
                padding: '8px 12px',
                cursor: 'pointer',
                borderRadius: '4px'
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;

