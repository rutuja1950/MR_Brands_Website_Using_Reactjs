// ✅ src/pages/ProfilePage/ProfilePage.jsx
import React, { useEffect, useState } from 'react';

const ProfilePage = () => {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const storedData = localStorage.getItem('userData');
    if (storedData) {
      setUserData(JSON.parse(storedData));
    }
  }, []);

  if (!userData) {
    return <p>No user data found. Please register first.</p>;
  }

  const orderedList = userData.orderedProducts?.split(',').map((item, index) => (
    <li key={index}>{item.trim()}</li>
  ));

  return (
    <div className="profile">
      <h2>User Profile</h2>
      <p><strong>Name:</strong> {userData.firstName} {userData.lastName}</p>
      <p><strong>Email:</strong> {userData.email}</p>
      <p><strong>Contact:</strong> {userData.contact}</p>
      <p><strong>Address:</strong> {userData.address}</p>
      <p><strong>Birthdate:</strong> {userData.birthdate}</p>
      <h3>Ordered Products:</h3>
      <ul>{orderedList}</ul>
    </div>
  );
};

export default ProfilePage;
