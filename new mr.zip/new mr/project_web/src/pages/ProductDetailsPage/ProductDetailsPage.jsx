// ✅ src/pages/ProductDetailsPage/ProductDetailsPage.jsx
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProduct } from '../../context/ProductContext';
import { useContext } from 'react';
import { CartContext } from '../../context/CartContext';

const ProductDetailsPage = () => {
  const { id } = useParams();
  const { products } = useProduct();
  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate();

  const product = products.find((p) => String(p.id) === id);

  if (!product) {
    return <p className="p-6 text-red-500">Product not found.</p>;
  }

  const handleBuyNow = () => {
  addToCart(product); // still add to cart
  navigate('/place-order', {
    state: { product, quantity: 1 },
  });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <img
          src={product.images?.split('~')[0].trim()}
          alt={product.name}
          className="w-full h-auto rounded-lg"
        />

        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <p className="text-xl text-green-700 font-semibold mb-2">₹{product.price}</p>
          <p className="text-gray-600 mb-4">{product.description}</p>

          <div className="text-sm text-gray-700 space-y-1 mb-4">
            <p><strong>Brand:</strong> {product.brand || 'N/A'}</p>
            <p><strong>Gender:</strong> {product.gender || 'Unisex'}</p>
            <p><strong>Category (MPN):</strong> {product.mpn || 'N/A'}</p>
          </div>

          <p className="mb-2">
            <strong>In Stock:</strong>{' '}
            {product.in_stock ? (
              <span className="text-green-600">Yes</span>
            ) : (
              <span className="text-red-600">No</span>
            )}
          </p>

          <div className="flex gap-4 mt-4">
            <button
              onClick={() => addToCart(product)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Add to Cart
            </button>

            <button
              onClick={handleBuyNow}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
            >
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailsPage;
