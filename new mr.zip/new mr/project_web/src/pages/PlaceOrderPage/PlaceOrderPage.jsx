import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
 // Assuming you have some styles for this page

const PlaceOrderPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const product = state?.product;
  const initialQuantity = state?.quantity || 1;

  const [quantity, setQuantity] = useState(initialQuantity);
  const [form, setForm] = useState({
    name: '',
    address: '',
    contact: '',
    paymentMode: 'cash',
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleQuantityChange = (e) => {
    const value = parseInt(e.target.value);
    if (value >= 1) setQuantity(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const order = {
      userDetails: form,
      productDetails: product,
      quantity,
    };

    // Save to localStorage temporarily
    const previousOrders = JSON.parse(localStorage.getItem('orders')) || [];
    localStorage.setItem('orders', JSON.stringify([...previousOrders, order]));

    alert('✅ Order Placed Successfully!');
    navigate('/'); // Redirect after placing
  };

  if (!product) {
    return <p className="text-red-500 p-6">No product selected for ordering.</p>;
  }

  return (
    <div className="p-6 max-w-3xl mx-auto " style={maincontainer1}>
      <h1 className="text-xl font-semibold mb-4">Place Order</h1>

      <div className="border p-4 rounded shadow mb-6 " style={maincontainer2}>
        <h2 className="text-lg font-semibold mb-2">""</h2>
        <img
          src={product.images?.split('~')[0].trim()}
          alt={product.name}
          style={placeorderimg}
        />
        <div className="mt-4" style={container1}>
        <p><strong>Name:</strong> {product.name}</p>
        <p><strong>Price:</strong> ₹{product.price}</p>
        <div className="mt-2">
          <label><strong>Quantity:</strong></label>
          <input
            type="number"
            min="1"
            value={quantity}
            onChange={handleQuantityChange}
            className="border p-2 rounded w-20 ml-2"
          />
        </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4" style={userfill}>
        <div>
          <label>Name:</label>
          <input name="name" value={form.name} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label>Address:</label>
          <textarea name="address" value={form.address} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label>Contact Number:</label>
          <input type="tel" name="contact" value={form.contact} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>

        <div>
          <label>Payment Mode:</label>
          <select name="paymentMode" value={form.paymentMode} onChange={handleChange} className="w-full border p-2 rounded">
            <option value="cash">Cash on Delivery</option>
            <option value="online">Online Payment</option>
          </select>
        </div>

        <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Submit Order</button>
      </form>
    </div>
  );
};

export default PlaceOrderPage;

const userfill = {
  display: 'flex',
  flexDirection: 'column',
  gap: '10px',
  marginTop: '20px',
  padding: '20px',
  backgroundColor: 'rgb(233, 12, 100)',
  borderRadius: '8px',
  boxShadow: '0 2px 4px rgb(236, 9, 9)',
}

const placeorderimg = {
  width: '300px',
  height: 'auto',
  maxHeight: '300px',
  objectFit: 'cover',
  backgroundsize: 'cover',
  borderRadius: '8px',
  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
};

const maincontainer1 = {
  backgroundColor: 'rgb(233, 12, 100)',
  padding: '20px',
  borderRadius: '8px',
  boxShadow: '0 2px 4px rgb(236, 9, 9)',
  marginBottom: '20px',
}

const maincontainer2 = {
  backgroundColor: 'white',
  padding: '20px',
  borderRadius: '8px',
  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  marginBottom: '20px',
  display: 'flex',
};

const container1 = {
  marginTop: '10px',
}

