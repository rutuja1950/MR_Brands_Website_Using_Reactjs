import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const SearchResults = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const query = queryParams.get('q') || '';

  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/assets/product.json');
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Failed to fetch product data:', error);
      }
    };

    fetchData();
  }, []);

  const filtered = products.filter((product) =>
    product.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div style={{ padding: '20px' }}>
      <h2>Search Results for "<span style={{ color: 'blue' }}>{query}</span>"</h2>

      {filtered.length > 0 ? (
        <div style={styles.grid}>
          {filtered.map((product) => (
            <div
              key={product.id}
              style={styles.card}
              onClick={() => navigate(`/product/${product.id}`)}
            >
              <img
                src={product.images}
                alt={product.name}
                style={styles.image}
              />
              <h3 style={styles.name}>{product.name}</h3>
              <p style={styles.price}>₹{product.price}</p>
            </div>
          ))}
        </div>
      ) : (
        <p>No results found.</p>
      )}
    </div>
  );
};

const styles = {
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '20px',
    marginTop: '20px',
  },
  card: {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '10px',
    textAlign: 'center',
    cursor: 'pointer',
    transition: 'transform 0.2s ease',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
  },
  image: {
    width: '100%',
    height: '180px',
    objectFit: 'cover',
    borderRadius: '4px',
  },
  name: {
    margin: '10px 0 5px',
    fontSize: '16px',
  },
  price: {
    fontWeight: 'bold',
    color: '#6200ea',
  },
};

export default SearchResults;



