
// ✅ src/services/authService.js
export const login = async (email, password) => {
  // Mocking login
  if (email === 'admin@test.com' && password === '123456') {
    return { success: true, user: { name: 'Admin', email } };
  }
  return { success: false, message: 'Invalid credentials' };
};

export const register = async (userData) => {
  // Mocking register
  console.log('Registering user:', userData);
  return { success: true, user: userData };
};
