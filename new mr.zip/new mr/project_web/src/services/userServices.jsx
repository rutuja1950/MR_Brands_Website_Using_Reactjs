// ✅ src/services/userService.js
export const getUserProfile = async (userId) => {
  return {
    id: userId,
    name: 'Test User',
    email: 'test@example.com',
  };
};