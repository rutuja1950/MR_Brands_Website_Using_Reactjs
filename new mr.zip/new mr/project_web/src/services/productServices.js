// // ✅ src/services/productService.js
// export const getProducts = async () => {
//   return [
//     { id: 1, name: 'Product 1', price: 100 },
//     { id: 2, name: 'Product 2', price: 200 },
//   ];
// };

// export const getProductById = async (id) => {
//   const products = await getProducts();
//   return products.find((product) => product.id === parseInt(id));
// };

// frontend/src/services/productService.js
const BASE_URL = 'http://localhost:5000/api/products';

export const fetchAllProducts = async () => {
  const response = await fetch(BASE_URL);
  return await response.json();
};

export const fetchProductById = async (id) => {
  const response = await fetch(`${BASE_URL}/${id}`);
  return await response.json();
};

