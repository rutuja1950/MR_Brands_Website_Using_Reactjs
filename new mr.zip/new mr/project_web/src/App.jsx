import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage/HomePage';
import CartPage from './pages/CartPage/CartPage';
import LoginPage from './pages/LoginPage/LoginPage';
import RegisterPage from './pages/RegisterPage/RegisterPage';
import ProductDetailsPage from './pages/ProductDetailsPage/ProductDetailsPage';
import PlaceOrderPage from './pages/PlaceOrderPage/PlaceOrderPage';
import ProfilePage from './pages/ProfilePage/ProfilePage';
import SearchResults from './pages/SearchResults/SearchResults';
import Header from './components/SharedLayout/Header';
import Footer from './components/SharedLayout/Footer';



const App = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/product/:id" element={<ProductDetailsPage />} />
        <Route path="/place-order" element={<PlaceOrderPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/search" element={<SearchResults />} />
      </Routes>
      <Footer />
    </>
  );
};

export default App;
