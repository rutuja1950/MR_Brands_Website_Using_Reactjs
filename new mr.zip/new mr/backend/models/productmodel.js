// backend/models/productModel.js
const pool = require('../db');

// Fetch all products from the database
const getAllProducts = async () => {
  const result = await pool.query('SELECT * FROM products');
  return result.rows;
};

// Fetch a product by ID
const getProductById = async (id) => {
  const result = await pool.query('SELECT * FROM products WHERE id = $1', [id]);
  return result.rows[0];
};

module.exports = {
  getAllProducts,
  getProductById,
};
