// backend/db.js
const { Pool } = require('pg');
require('dotenv').config();

// Create a pool to manage PostgreSQL connections
const pool = new Pool({
  user: process.env.postgres,         // your DB username
  host: process.env.localhost,         // usually localhost
  database: process.env.productdb, // database name
  password: process.env.rutu123, // password
  port: process.env.t5432,         // 5432 by default
});

module.exports = pool;
