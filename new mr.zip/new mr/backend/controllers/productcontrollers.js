// backend/controllers/productController.js
const productModel = require('../models/productmodel');

// Controller to send all products
const getProducts = async (req, res) => {
  try {
    const products = await productModel.getAllProducts();
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: 'Server error fetching products.' });
  }
};

// Controller to send a product by ID
const getProduct = async (req, res) => {
  try {
    const id = req.params.id;
    const product = await productModel.getProductById(id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found.' });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: 'Server error fetching product.' });
  }
};

module.exports = {
  getProducts,
  getProduct,
};
